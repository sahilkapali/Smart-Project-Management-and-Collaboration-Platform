import { ROLE } from "./enum.types";

declare global {
  namespace Express {
    interface User {
      id: string;
      role: ROLE;
    }
  }
}

export {};
